import p1_img from "./product_1.webp";
import p2_img from "./product_2.webp";
import p3_img from "./product_3.webp";
import p4_img from "./product_4.webp";
import p5_img from "./product_5.webp";
import p6_img from "./product_6.webp";
import p7_img from "./product_7.webp";
import p8_img from "./product_8.webp";


let new_collections=[
    {
            id:1,
            name:"Abebe",
            image:p1_img,
            new_price:50.0,
            old_price:80.5,
        },
        {
            id:2,
            name:"Abebe",
            image:p2_img,
            new_price:500.0,
            old_price:800.5,
        },
        {
            id:3,
            name:"Abebe",
            image:p3_img,
            new_price:520.0,
            old_price:880.5,
        },
        {
            id:4,
            name:"Abebe",
            image:p4_img,
            new_price:22.0,
            old_price:180.5,
        },
        {
            id:5,
            name:"Abebe",
            image:p5_img,
            new_price:50.0,
            old_price:80.5,
        },
        {
            id:6,
            name:"Abebe",
            image:p6_img,
            new_price:50.0,
            old_price:80.5,
        },
        {
            id:7,
            name:"Abebe",
            image:p7_img,
            new_price:50.0,
            old_price:80.5,
        },
        {
            id:8,
            name:"Abebe",
            image:p8_img,
            new_price:50.0,
            old_price:80.5,
        },
        
]
export default new_collections;